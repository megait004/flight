import HeroSection from '@pages/Client/Index/HeroSection';
import React from 'react';

const Index: React.FC = () => {
	return (
		<>
			<HeroSection />
		</>
	);
};

export default Index;
