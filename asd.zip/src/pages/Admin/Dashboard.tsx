import React from 'react';

const Dashboard: React.FC = () => {
	return <>adasd</>;
};

export default Dashboard;
