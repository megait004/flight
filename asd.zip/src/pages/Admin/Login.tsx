import React from 'react';

const Login: React.FC = () => {
	return <>Login</>;
};

export default Login;
